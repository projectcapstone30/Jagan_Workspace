# Feedback Management System DashBoard application

This FMS DashBoard application is used to get the statistics of FeedbackManagementSystem 
Implemented Spring Security Using JWT token with Role Based Authentication and Authorization

# Login As Admin

### Request

'POST /login/'
	
	http://localhost:8585/login
	
### Request Body
	
	{
    "username": "admin",
    "password": "admin"
	}
	
### Response 

	{
    	"token": "eyJhbGciOiJIUzUxMiJ9.eyJyb2xlIjpbIlJPTEVfQURNSU4iXSwic3ViIjoiYWRtaW4iLCJpYXQiOjE1ODc0MTc1NzUsImV4cCI6MTU4NzQ0NjM3NX0.5ivO9Kf8OY0STyJquAXkfSTmliBzs2u8Z-ETfqC3E26zCpYqfyZ7k6V1PpAf2QQ-VjBGB4--vLbyximWttEk6A"
	} 
	
================================ Like Wise Based on Role login and access the Rest API PMO and POC ========================================

# REST API

The REST APIs to Feedback Management System Dashboard app is described below.

## Save Events From DataBase

### Request

`POST /events/addEvent/`

	 http://localhost:8585/events/addEvent/
	 
	 Authentication = Bearar Token  (ADMIN)
	 
	 Bearar eyJhbGciOiJIUzUxMiJ9.eyJyb2xlIjpbIlJPTEVfQURNSU4iXSwic3ViIjoiYWRtaW4iLCJpYXQiOjE1ODc0MTc1NzUsImV4cCI6MTU4NzQ0NjM3NX0.5ivO9Kf8OY0STyJquAXkfSTmliBzs2u8Z-ETfqC3E26zCpYqfyZ7k6V1PpAf2QQ-VjBGB4--vLbyximWttEk6A

### Response 

	data:{"eventId":4,"eventName":"tom","eventDate":"4-6-2010","businessUnit":"care","venue":"newZeeland","totalVollunteers":15,"totalParticipants":20,"livesImpacted":9,"vallunteerHours":8,"travelHours":1}



## Get All Events

### Request

'GET' /events/allEvents/

	http://localhost:8585/events/allEvents
	
	Authentication = Bearar Token  (ADMIN)
	 
	Bearar eyJhbGciOiJIUzUxMiJ9.eyJyb2xlIjpbIlJPTEVfQURNSU4iXSwic3ViIjoiYWRtaW4iLCJpYXQiOjE1ODc0MTc1NzUsImV4cCI6MTU4NzQ0NjM3NX0.5ivO9Kf8OY0STyJquAXkfSTmliBzs2u8Z-ETfqC3E26zCpYqfyZ7k6V1PpAf2QQ-VjBGB4--vLbyximWttEk6A
	
	
### Response

	data:{"eventId":4,"eventName":"tom","eventDate":"4-6-2010","businessUnit":"care","venue":"newZeeland","totalVollunteers":15,"totalParticipants":20,"livesImpacted":9,"vallunteerHours":8,"travelHours":1}


## Get Events By eventId

### Request

'GET' /events/eventDetails/

	http://localhost:8585/events/eventDetails/
	
	Authentication = Bearar Token   (ADMIN)
	 
	Bearar eyJhbGciOiJIUzUxMiJ9.eyJyb2xlIjpbIlJPTEVfQURNSU4iXSwic3ViIjoiYWRtaW4iLCJpYXQiOjE1ODc0MTc1NzUsImV4cCI6MTU4NzQ0NjM3NX0.5ivO9Kf8OY0STyJquAXkfSTmliBzs2u8Z-ETfqC3E26zCpYqfyZ7k6V1PpAf2QQ-VjBGB4--vLbyximWttEk6A
	
	## Add Request Param in Params Tab
	KEY: eventId   Value: 4
	
### Response

	data:{"eventId":4,"eventName":"tom","eventDate":"4-6-2010","businessUnit":"care","venue":"newZeeland","totalVollunteers":15,"totalParticipants":20,"livesImpacted":9,"vallunteerHours":8,"travelHours":1}

	
## Delete Events By EventID

### Request

'GET' /events/deleteEvent/

	http://localhost:8585/events/deleteEvent/
	
	Authentication = Bearar Token   (ADMIN)
	 
	Bearar eyJhbGciOiJIUzUxMiJ9.eyJyb2xlIjpbIlJPTEVfQURNSU4iXSwic3ViIjoiYWRtaW4iLCJpYXQiOjE1ODc0MTc1NzUsImV4cCI6MTU4NzQ0NjM3NX0.5ivO9Kf8OY0STyJquAXkfSTmliBzs2u8Z-ETfqC3E26zCpYqfyZ7k6V1PpAf2QQ-VjBGB4--vLbyximWttEk6A
	
	## Add Request Param in Params Tab
	KEY: eventId   Value: 4

### Response

	Http Status : 200 Ok


## Delete All Events

### Request

'GET' /events/deleteAllEvents/

	http://localhost:8585/events/deleteAllEvents/
	
	Authentication = Bearar Token   (ADMIN)
	 
	Bearar eyJhbGciOiJIUzUxMiJ9.eyJyb2xlIjpbIlJPTEVfQURNSU4iXSwic3ViIjoiYWRtaW4iLCJpYXQiOjE1ODc0MTc1NzUsImV4cCI6MTU4NzQ0NjM3NX0.5ivO9Kf8OY0STyJquAXkfSTmliBzs2u8Z-ETfqC3E26zCpYqfyZ7k6V1PpAf2QQ-VjBGB4--vLbyximWttEk6A

### Response

	Http Status : 200 Ok
	
	
## Get DashBoard statistics

### Request

'GET' /events/getDashboardData/

	http://localhost:8585/events/getDashboardData/
	
	Authentication = Bearar Token   (ADMIN)
	 
	Bearar eyJhbGciOiJIUzUxMiJ9.eyJyb2xlIjpbIlJPTEVfQURNSU4iXSwic3ViIjoiYWRtaW4iLCJpYXQiOjE1ODc0MTc1NzUsImV4cCI6MTU4NzQ0NjM3NX0.5ivO9Kf8OY0STyJquAXkfSTmliBzs2u8Z-ETfqC3E26zCpYqfyZ7k6V1PpAf2QQ-VjBGB4--vLbyximWttEk6A

### Response

	data:{"count":1,"totalVolunteers":21,"livesImpacted":6,"totalParticipants":0}

