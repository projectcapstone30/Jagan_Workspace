package com.capstone.FeedbackManagementSystem.model;

import reactor.core.publisher.Mono;

public class Dashboard {
private int count;
private int totalVolunteers;
private int livesImpacted;
private int totalParticipants;
public int getCount() {
	return count;
}
public void setCount(int count) {
	this.count = count;
}
public int getTotalVolunteers() {
	return totalVolunteers;
}
public void setTotalVolunteers(int totalVolunteers) {
	this.totalVolunteers = totalVolunteers;
}
public int getLivesImpacted() {
	return livesImpacted;
}
public void setLivesImpacted(int livesImpacted) {
	this.livesImpacted = livesImpacted;
}
public int getTotalParticipants() {
	return totalParticipants;
}
public void setTotalParticipants(int totalParticipants) {
	this.totalParticipants = totalParticipants;
}




}
