package com.capstone.FeedbackManagementSystem.repository;

import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
import org.springframework.stereotype.Repository;

import com.capstone.FeedbackManagementSystem.model.Event;

import reactor.core.publisher.Flux;
@Repository
public interface EventRepository extends ReactiveMongoRepository<Event, Integer> {
	
}
