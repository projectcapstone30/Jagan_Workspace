package com.capstone.feedbackmanagementsystem.exceltodb.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import com.capstone.feedbackmanagementsystem.exceltodb.Service.EventService;
import com.capstone.feedbackmanagementsystem.exceltodb.entity.Events;

import reactor.core.publisher.Flux;

@RestController
public class EventController {
	
	@Autowired
	private EventService eventService;
	
	  @GetMapping(value = "/readExcel", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
	  public Flux<Object> uploadFile() throws Exception {
		  return eventService.saveExcelData();
	  }
		
	  @GetMapping(value = "/getEvents") 
	  public Flux<Events> getEvents(){
		  return eventService.getAllEvents();
	  }
	 
	
}
