package com.capstone.feedbackmanagementsystem.exceltodb.Service;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.capstone.feedbackmanagementsystem.exceltodb.entity.Events;
import com.capstone.feedbackmanagementsystem.exceltodb.repository.EventRepository;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Component
public class EventService {
	
	@Autowired
	private EventRepository eventRepository;
	
	public Flux<Object> saveExcelData() throws InvalidFormatException, IOException{		
		
		File file1 = new File("data.xlsx");   //creating a new file instance  
		FileInputStream file = new FileInputStream(file1);
		List<Events> eventList = new ArrayList<Events>();
		XSSFWorkbook workbook = new XSSFWorkbook(file1);
    	XSSFSheet worksheet =  workbook.getSheetAt(0);
		for(int i=1;i<worksheet.getPhysicalNumberOfRows() ;i++)
		  {
			 Events tempEvents = new Events();
			  XSSFRow row = worksheet.getRow(i);
			 
			  tempEvents.setEvent_id(row.getCell(0).getStringCellValue());
			  tempEvents.setBase_location(row.getCell(1).getStringCellValue());
			  tempEvents.setBeneficiary_name(row.getCell(2).getStringCellValue());
			  tempEvents.setCouncil_name(row.getCell(3).getStringCellValue());
			  tempEvents.setEvent_name(row.getCell(4).getStringCellValue());
			  tempEvents.setEvent_description(row.getCell(5).getStringCellValue());
			  tempEvents.setEvent_date(row.getCell(6).getDateCellValue());
			  tempEvents.setEmployee_id(row.getCell(7).getStringCellValue());
			  tempEvents.setEmployee_name(row.getCell(8).getStringCellValue());
			  tempEvents.setVolunteer_hours((int) row.getCell(9).getNumericCellValue());
			  tempEvents.setTravel_hours((int) row.getCell(10).getNumericCellValue());
			  tempEvents.setLives_impacted((int) row.getCell(11).getNumericCellValue());
			  tempEvents.setBusiness_unit(row.getCell(12).getStringCellValue());
			  tempEvents.setEvent_status(row.getCell(13).getStringCellValue());
			  tempEvents.setIiep_category(row.getCell(14).getStringCellValue());
			  eventList.add(tempEvents);
			  
		  }
		  return eventRepository.saveAll(eventList)
				 .map(savedEvent -> ResponseEntity.ok(savedEvent));
	}
	
	public Flux<Events> getAllEvents(){
		return eventRepository.findAll();
	}
	
}
